function handleLogin() {
    alert("Login clicado!");
  }
  
  function handleCreateAccount() {
    alert("Criar Conta clicado!");
  }
  